# for x in range(0,150):
#   print(x)

# for i in range(5, 1000,5):
#   print(i)

# for i in range(1, 100):
#   print(i)
#   if(i % 5):
#     print("coding")
#   elif(i % 10):
#     print('Coding Dojo')

# for i in range(2018,0,-4):
#   print(i)

